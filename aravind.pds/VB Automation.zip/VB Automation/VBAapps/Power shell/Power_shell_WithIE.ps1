$ie= new-object -ComObject InternetExplorer.Application
$ie.navigate(“http://www.google.com”)
 
while ($ie.busy) {
 sleep -milliseconds 100
 }

$List = New-Object Collections.Generic.List[String]
 
$ie.visible=$true
$ie.Document.getElementById(“q”).value=”weather in dallas”
$ie.visible=$false
$ie.visible=$true
$ie.document.forms | 
    Select -First 1 | 
        % { $_.submit() }

while ($ie.busy) {
 sleep -milliseconds 100
}

foreach($sw in $ie.document.getElementById("search").getElementsByTagName("h3")) {
  $List += $sw.innerText;
} 
$List | out-file "H:\ProfileUnity\Desktop\Power shell\aravindlog.txt"