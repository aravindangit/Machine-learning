$ie = New-Object -ComObject InternetExplorer.Application
$ie.Navigate("http://www.google.com")
while ($ie.busy) {
 sleep -milliseconds 100
 }
$List = New-Object Collections.Generic.List[String]
$ie.Visible = $true
$ie.Document.getElementById("q").value="weather in dallas"